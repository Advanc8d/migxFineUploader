<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxfineuploader-0.2.3-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '72120cc954c81874cef8cfca572b2043',
      'native_key' => 'migxfineuploader',
      'filename' => 'modNamespace/ae63164b8e5504603a037fcfa3ae2dd2.vehicle',
      'namespace' => 'migxfineuploader',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'beb81f445225e1e80e8ad49c55cced20',
      'native_key' => 1,
      'filename' => 'modCategory/eb947ab5f694b50b09d04e6fa9ae8230.vehicle',
      'namespace' => 'migxfineuploader',
    ),
  ),
);