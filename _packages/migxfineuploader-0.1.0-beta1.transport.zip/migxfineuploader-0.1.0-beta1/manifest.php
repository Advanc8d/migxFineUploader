<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxfineuploader-0.1.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6b47938690c41a12eb61b26dbe0a7b94',
      'native_key' => 'migxfineuploader',
      'filename' => 'modNamespace/919bcccc9194df326df3836e7bbd7de2.vehicle',
      'namespace' => 'migxfineuploader',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'caeebb256d02b636c0ce5bf037aab25b',
      'native_key' => 1,
      'filename' => 'modCategory/4613329b0ae9a28499f26ee28bbb439c.vehicle',
      'namespace' => 'migxfineuploader',
    ),
  ),
);