<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxfineuploader-0.2.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fc3ba3fedffdcbd4b4552886367a2d57',
      'native_key' => 'migxfineuploader',
      'filename' => 'modNamespace/83e6c0cdbeccbbef3dd2980a37865d4a.vehicle',
      'namespace' => 'migxfineuploader',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '02e6a0e3a4c451216bc793a97151a23a',
      'native_key' => 1,
      'filename' => 'modCategory/d8ec6fd3577ffe751e86f64ee2ac72d3.vehicle',
      'namespace' => 'migxfineuploader',
    ),
  ),
);