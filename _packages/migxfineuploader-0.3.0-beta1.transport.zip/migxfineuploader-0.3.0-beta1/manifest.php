<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxfineuploader-0.3.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '355bf8a4ba1e462ab8a76e290a0f2faf',
      'native_key' => 'migxfineuploader',
      'filename' => 'modNamespace/000854c695ded4d079031987e7a2b34b.vehicle',
      'namespace' => 'migxfineuploader',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3d6fc690e37f7b000c8491b75e1204d3',
      'native_key' => 1,
      'filename' => 'modCategory/c399e87642e8b0fd4cbee6a818324e5e.vehicle',
      'namespace' => 'migxfineuploader',
    ),
  ),
);