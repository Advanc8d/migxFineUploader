<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxfineuploader-0.3.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4f43f12621d1ce63c1bddd3f862991ed',
      'native_key' => 'migxfineuploader',
      'filename' => 'modNamespace/7e167c595b7e3e3c3096fec0268a2649.vehicle',
      'namespace' => 'migxfineuploader',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9f19678e769d0b5bd8d266886ec32818',
      'native_key' => 1,
      'filename' => 'modCategory/56578b3b2c7cc0da9153490a1bda68c1.vehicle',
      'namespace' => 'migxfineuploader',
    ),
  ),
);