<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxfineuploader-0.2.1-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '126c9751552faa49be3effdbf7a069a0',
      'native_key' => 'migxfineuploader',
      'filename' => 'modNamespace/278ec3de04dd5928403407200584dd80.vehicle',
      'namespace' => 'migxfineuploader',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a54a2b31e5bd6e6bc7fefa0cd6eac522',
      'native_key' => 1,
      'filename' => 'modCategory/7bb5d8e30687f18a98a462e8928b3d98.vehicle',
      'namespace' => 'migxfineuploader',
    ),
  ),
);